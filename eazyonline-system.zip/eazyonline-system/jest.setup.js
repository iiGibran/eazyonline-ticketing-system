global.alert = jest.fn();
